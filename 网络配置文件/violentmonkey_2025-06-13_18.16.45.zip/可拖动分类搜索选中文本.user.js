// ==UserScript==
// @name         可拖动分类搜索选中文本
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  添加一个可拖动的按钮以搜索选中的文本，支持分类搜索引擎选择。
// @author       Your Name
// @match        *://*/*
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function() {
    'use strict';

    // 创建浮动按钮
    const button = document.createElement('button');
    button.innerText = '搜索';
    button.style.position = 'fixed';
    button.style.bottom = '400px'; // 默认位置
    button.style.right = '10px';  // 默认位置
    button.style.padding = '10px';
    button.style.backgroundColor = '#007bff';
    button.style.color = '#fff';
    button.style.border = 'none';
    button.style.borderRadius = '5px';
    button.style.cursor = 'pointer';
    button.style.zIndex = '1000';
    button.style.width = 'auto'; // 确保尺寸不变
    button.style.height = 'auto';

    // 添加拖动功能
    let isDragging = false;
    let offsetX = 0, offsetY = 0;

    button.onmousedown = function(e) {
        e.preventDefault();
        isDragging = true;
        offsetX = e.clientX - button.getBoundingClientRect().left;
        offsetY = e.clientY - button.getBoundingClientRect().top;
    };

    document.onmousemove = function(e) {
        if (isDragging) {
            button.style.left = `${e.clientX - offsetX}px`;
            button.style.top = `${e.clientY - offsetY}px`;
        }
    };

    document.onmouseup = function() {
        isDragging = false;
    };

    // 将按钮添加到页面
    document.body.appendChild(button);

    // 从油猴存储中获取最近搜索的词
    const lastSearchTerm = GM_getValue('lastSearchTerm', '');

    // 默认是否展开菜单
    let isExpanded = true;

    // 按钮点击事件
    button.onclick = () => {
        let selectedText = window.getSelection().toString().trim(); // 获取选中的文本

        // 如果没有选中任何文本，使用最近的搜索词或提示用户输入
        if (!selectedText) {
            selectedText = lastSearchTerm || prompt('请输入搜索词：');
            if (!selectedText) return; // 如果用户没有输入，直接返回
        }

        // 存储最新搜索词到油猴变量中
        GM_setValue('lastSearchTerm', selectedText);

        // 搜索引擎按分类
        const searchEngines = {
            '常用搜索引擎': [
                { name: 'Google', url: 'https://www.google.com/search?q=' },
                { name: 'Bing', url: 'https://www.bing.com/search?q=' }
            ],
            '隐私搜索引擎': [
                { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=' },
                { name: 'StartPage', url: 'https://www.startpage.com/do/search?query=' }
            ],
            '本地搜索引擎': [
                { name: '百度', url: 'https://www.baidu.com/s?wd=' },
                { name: '搜狗', url: 'https://www.sogou.com/sogou?query=' }
            ],
                  "fanaho": [
            {"name": "javbus","url": "https://www.javbus.com/search/%s"},
            {"name": "jable","url": "https://jable.tv/search/%s/"},
            {"name": "javfc2","url": "https://javfc2.net/?s=%s/"},
            {
                "name": "bad.news",
                "url": "https://bad.news/av/search/q-%s"
            },
            {
                "name": "jpvhub",
                "url": "https://www.jpvhub.com/cn/search/%s/"
            },
            {
                "name": "eyny",
                "url": "https://www.eyny.com/channel/UCXVtaFCKWX/tag/%s"
            },
            {
                "name": "P站",
                "url": "https://www.pornhub.com/video/search?search=%s"
            },
            {
                "name": "X站",
                "url": "https://www.xvideos.com/?k=%s"
            }]
        };

        // 创建搜索引擎选择菜单
        const menu = document.createElement('div');
        menu.style.position = 'fixed';
        menu.style.bottom = '370px';
        menu.style.right = '60px';
        menu.style.backgroundColor = '#fff';
        menu.style.border = '1px solid #ccc';
        menu.style.borderRadius = '5px';
        menu.style.zIndex = '1001';
        menu.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
        menu.style.padding = '10px';
        menu.style.whiteSpace = 'nowrap'; // 横向排列

        // 创建是否展开选项
        const toggleButton = document.createElement('button');
        toggleButton.innerText = isExpanded ? '收起菜单' : '展开菜单';
        toggleButton.style.marginBottom = '10px';
        toggleButton.style.cursor = 'pointer';
        toggleButton.onclick = () => {
            isExpanded = !isExpanded;
            toggleButton.innerText = isExpanded ? '收起菜单' : '展开菜单';
            engineList.style.display = isExpanded ? 'block' : 'none'; // 控制菜单展开
        };

        // 添加搜索引擎分类
        const engineList = document.createElement('div');
        engineList.style.display = isExpanded ? 'block' : 'none'; // 根据默认值控制显示

        for (const [category, engines] of Object.entries(searchEngines)) {
            const categoryDiv = document.createElement('div');
            categoryDiv.innerText = category;
            categoryDiv.style.fontWeight = 'bold';
            categoryDiv.style.cursor = 'pointer';
            categoryDiv.style.padding = '5px 0';
            categoryDiv.style.borderBottom = '1px solid #ccc';

            const engineContainer = document.createElement('div');
            engineContainer.style.display = 'flex'; // 横向排列
            engineContainer.style.justifyContent = 'space-between';
            engineContainer.style.flexWrap = 'wrap';

            engines.forEach(engine => {
                const option = document.createElement('div');
                option.innerText = engine.name;
                option.style.cursor = 'pointer';
                option.style.padding = '5px';
                option.addEventListener('click', () => {
                    const searchUrl = engine.url + encodeURIComponent(selectedText);
                    window.open(searchUrl, '_blank'); // 在新标签页中打开搜索结果
                    document.body.removeChild(menu); // 移除菜单
                });
                engineContainer.appendChild(option);
            });

            categoryDiv.appendChild(engineContainer);
            engineList.appendChild(categoryDiv);
        }

        // 将切换按钮和搜索引擎列表添加到菜单
        menu.appendChild(toggleButton);
        menu.appendChild(engineList);

        // 点击外部时移除菜单
        document.body.appendChild(menu);
        menu.addEventListener('mouseleave', () => {
            document.body.removeChild(menu); // 移除菜单
        });
    };
})();
