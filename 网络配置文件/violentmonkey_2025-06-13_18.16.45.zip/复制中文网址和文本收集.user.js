// ==UserScript==
// @name         复制中文网址和文本收集
// @namespace    http://tampermonkey.net/
// @version      0.7
// @author       dennis
// @description  在页面左上角添加书签按钮，并提供跨页面文本收集功能
// @match        *://*/*
// @grant        GM_setClipboard
// @grant        GM_setValue
// @grant        GM_getValue
// @run-at       document-end
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/513413/%E5%A4%8D%E5%88%B6%E4%B8%AD%E6%96%87%E7%BD%91%E5%9D%80%E5%92%8C%E6%96%87%E6%9C%AC%E6%94%B6%E9%9B%86.user.js
// @updateURL https://update.greasyfork.org/scripts/513413/%E5%A4%8D%E5%88%B6%E4%B8%AD%E6%96%87%E7%BD%91%E5%9D%80%E5%92%8C%E6%96%87%E6%9C%AC%E6%94%B6%E9%9B%86.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // 创建书签按钮
    function createBookmarkButton() {
        const button = document.createElement('div');
        button.id = 'bookmark-button';
        button.style.cssText = `
            position: fixed;
            top: 10px;
            left: 0;
            width: 12px;
            height: 25px;
            border-radius: 0 12px 12px 0;
            background-color: rgba(144, 238, 144, 0.5);
            cursor: pointer;
            z-index: 9999999;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            font-size: 14px;
            color: rgba(0, 0, 0, 0.6);
            transition: all 0.3s ease;
            overflow: hidden;
        `;

        button.innerHTML = '<span style="margin-right: 3px;">❐</span>';

        button.addEventListener('mouseenter', function() {
            this.style.width = '25px';
            this.style.justifyContent = 'center';
            this.innerHTML = '❐+';
        });

        button.addEventListener('mouseleave', function() {
            this.style.width = '12px';
            this.style.justifyContent = 'flex-end';
            this.innerHTML = '<span style="margin-right: 3px;">❐</span>';
        });

        button.addEventListener('click', function() {
            const title = document.title;
            const url = decodeURI(window.location.href);
            const markdown = `>【参考：[${title}](${url})】`;
            GM_setClipboard(markdown);
            alert('已复制到剪贴板!');
        });

        document.body.appendChild(button);
    }

    // 创建文本收集框
    function createTextCollector() {
        const collector = document.createElement('div');
        collector.id = 'text-collector';
        collector.style.cssText = `
            position: fixed;
            bottom: 10px;
            right: 10px;
            width: 300px;
            height: 200px;
            background-color: rgba(255, 255, 255, 0.9);
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            font-size: 14px;
            z-index: 9999999;
            display: none;
            flex-direction: column;
        `;

        const buttonContainer = document.createElement('div');
        buttonContainer.style.cssText = `
            position: absolute;
            top: 5px;
            right: 5px;
            display: flex;
        `;

        const clearButton = document.createElement('div');
        clearButton.innerHTML = '🗑️';
        clearButton.style.cssText = `
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            opacity: 0.4;
            filter: grayscale(100%) brightness(0.8);
            transition: opacity 0.3s ease, filter 0.3s ease;
        `;
        clearButton.addEventListener('mouseenter', function() {
            this.style.opacity = '0.8';
            this.style.filter = 'none';
        });
        clearButton.addEventListener('mouseleave', function() {
            this.style.opacity = '0.4';
            this.style.filter = 'grayscale(100%) brightness(0.8)';
        });
        clearButton.addEventListener('click', () => {
            textArea.value = '';
            GM_setValue('collectedText', '');
        });

        const closeButton = document.createElement('div');
        closeButton.innerHTML = '✖';
        closeButton.style.cssText = `
            cursor: pointer;
            font-size: 14px;
        `;
        closeButton.addEventListener('click', () => {
            collector.style.display = 'none';
            GM_setValue('collectorVisible', false);
        });

        buttonContainer.appendChild(clearButton);
        buttonContainer.appendChild(closeButton);

        const textArea = document.createElement('textarea');
        textArea.style.cssText = `
            flex-grow: 1;
            resize: none;
            border: none;
            outline: none;
            background-color: transparent;
        `;

        // 从存储中加载文本
        textArea.value = GM_getValue('collectedText', '');

        // 监听文本变化并保存
        textArea.addEventListener('input', () => {
            GM_setValue('collectedText', textArea.value);
        });

        collector.appendChild(buttonContainer);
        collector.appendChild(textArea);
        document.body.appendChild(collector);

        // 恢复收集框的可见状态
        if (GM_getValue('collectorVisible', false)) {
            collector.style.display = 'flex';
        }

        return { collector, textArea };
    }

    // 初始化
    createBookmarkButton();
    const { collector, textArea } = createTextCollector();

    // 监听键盘事件
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'x') {
            e.preventDefault(); // 阻止默认的剪切行为
            const selectedText = window.getSelection().toString().trim();
            if (selectedText) {
                if (collector.style.display === 'none') {
                    collector.style.display = 'flex';
                    GM_setValue('collectorVisible', true);
                    textArea.value += (textArea.value ? '\n' : '') + selectedText;
                } else {
                    textArea.value += '\n' + selectedText;
                }
                GM_setValue('collectedText', textArea.value);
                GM_setClipboard(textArea.value);
            }
        }
    });

})();
