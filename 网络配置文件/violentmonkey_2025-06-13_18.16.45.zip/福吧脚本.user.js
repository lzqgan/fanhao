// ==UserScript==
// @name        福吧脚本
// @namespace   Violentmonkey Scripts
// @include             /www.wnflb\d*.com/
// @include             /fuliba2023.net/
// @grant       none
// @version     1.0
// @author      -
// @description 2024/10/18 21:42:30
// @icon         https://www.google.com/s2/favicons?sz=64&domain=fuliba2023.net
// ==/UserScript==

//百家姓，油管补全
(function () {
    'use strict';

    const obja = {
        "赵": "0", "钱": "1", "孙": "2", "李": "3", "周": "4", "吴": "5",
        "郑": "6", "王": "7", "冯": "8", "陈": "9", "褚": "a", "卫": "b",
        "蒋": "c", "沈": "d", "韩": "e", "杨": "f", "朱": "g", "秦": "h",
        "尤": "i", "许": "j", "何": "k", "吕": "l", "施": "m", "张": "n",
        "孔": "o", "曹": "p", "严": "q", "华": "r", "金": "s", "魏": "t",
        "陶": "u", "姜": "v", "戚": "w", "谢": "x", "邹": "y", "喻": "z",
        "福": "A", "水": "B", "窦": "C", "章": "D", "云": "E", "苏": "F",
        "潘": "G", "葛": "H", "奚": "I", "范": "J", "彭": "K", "郎": "L",
        "鲁": "M", "韦": "N", "昌": "O", "马": "P", "苗": "Q", "凤": "R",
        "花": "S", "方": "T", "俞": "U", "任": "V", "袁": "W", "柳": "X",
        "唐": "Y", "罗": "Z", "薛": ".", "伍": "-", "余": "_", "米": "+",
        "贝": "=", "姚": "/", "孟": "?", "顾": "#", "尹": "%", "江": "&",
        "钟": "*"
    };

    function dict2pattern(dict) {
        var cnPattern = ''
        for (let i in obja) {
            cnPattern += i
        }
        return new RegExp(`[${cnPattern}]{10,}`, "gm")
    }

    let cnPattern = dict2pattern(obja)
    let youtubePattern = /watch\?v=/;

    let ps = document.querySelectorAll('p')
    ps.forEach(e => {
        let str = e.innerText
        if (str.match(cnPattern)) {
            let res = [...str.matchAll(cnPattern)]
            res.forEach(r => {
                // console.log(r[0])
                if (r[0].length === 40) {
                    e.style.color = "red"
                    e.innerText = e.innerText.replace(r[0],bjx2mag(r[0]))
                } else {
                    e.style.color = "yellowgreen"
                    e.innerText = e.innerText.replace(r[0],bjx2mag(r[0]))
                }
            })

        }
        if (youtubePattern.test(str)) {
        const videoId = str.split('?v=')[1];
        const aTag = document.createElement('a');
        aTag.href = `https://www.youtube.com/watch?v=${videoId}`;
        aTag.innerText = "油管链接";
        e.appendChild(aTag);
        }

    })

    function bjx2mag(bjx) {
        let str = bjx.replace(/^\s\s*/, '').replace(/\s\s*$/, '').split("");
        let c = ""
        if (str.length === 40) {
            c = "magnet:?xt=urn:btih:"
            for (let i of str) {
                c += obja[i]
            }
        } else {
            for (let i of str) {
                c += obja[i]
            }
        }

        return c
    }

})();









///论坛按最新发帖排序------------------

// (function() {
//     'use strict';

//     // 替换规则
//     var replacements = [
//         {
//             from: /https:\/\/www\.wnflb2023\.com\/forum-(\d+)-(\d+)\.html/g,
//             to: 'https://www.wnflb2023.com/forum.php?mod=forumdisplay&fid=$1&filter=author&orderby=dateline'
//         }
//     ];

//     // 检查并替换网址
//     function replaceURL() {
//         var currentURL = window.location.href;
//         for (var i = 0; i < replacements.length; i++) {
//             var replacement = replacements[i];
//             if (replacement.from.test(currentURL)) {
//                 var newURL = currentURL.replace(replacement.from, replacement.to);
//                 window.location.href = newURL;
//                 break;
//             }
//         }
//     }

//     // 执行网址替换
//     replaceURL();

// })();



//签到功能
// (function() {
//         'use strict';

//         // 签到功能，仅在论坛主页执行
//         function autoSignIn() {
//             if (window.location.href.indexOf('forum.php') > -1) {
//                 var signInButton = document.getElementById('fx_checkin_topb');
//                 var signInStatus = signInButton ? signInButton.querySelector('img').alt : '';

//                 if (signInButton && signInStatus !== '已签到') {
//                     console.log('签到按钮可见且未签到，尝试签到...');
//                     signInButton.click();
//                     console.log('签到尝试完成。');
//                 } else if (signInStatus === '已签到') {
//                     console.log('已经签到，不进行操作。');
//                 } else {
//                     console.log('未找到签到按钮，可能页面尚未完全加载或已签到。');
//                 }
//             }
//         }})();