// ==UserScript==
// @name         返回顶部和底部-美化版
// @version      1.0.5
// @description  一个很漂亮的可返回顶部或底部的可拖拽的按钮
// @author       沐雨
// @license      MIT
// @match        *://*/*
// @grant        GM_info
// @grant        GM_addStyle
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_getResourceText
// @require      http://code.jquery.com/jquery-1.11.0.min.js
// @require      https://cdn.bootcdn.net/ajax/libs/interact.js/1.10.17/interact.min.js
// @namespace    https://www.yuxi.com/
// @downloadURL https://update.greasyfork.org/scripts/457039/%E8%BF%94%E5%9B%9E%E9%A1%B6%E9%83%A8%E5%92%8C%E5%BA%95%E9%83%A8-%E7%BE%8E%E5%8C%96%E7%89%88.user.js
// @updateURL https://update.greasyfork.org/scripts/457039/%E8%BF%94%E5%9B%9E%E9%A1%B6%E9%83%A8%E5%92%8C%E5%BA%95%E9%83%A8-%E7%BE%8E%E5%8C%96%E7%89%88.meta.js
// ==/UserScript==

;(function () {
	'use strict'
	var TBLink = function () {
		var $ = $ || window.$
		var $doc = $(document)
		var $win = $(window)
		// const iconFont = GM_getResourceText('css')
		var CreateHtml = function () {
			var html = `
      <div id="goTopBottom" style="display:flex;justify-content: center;align-items: center;width:50px;height:100px;">
                      <span class="t-btn gotop" title="返回顶部" style="opacity: 0;">
                        <svg t="1681901274619" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3044" id="mx_n_1681901274619" width="22" height="22"><path d="M199.36 572.768a31.904 31.904 0 0 0 22.624-9.376l294.144-294.144 285.728 285.728a31.968 31.968 0 1 0 45.248-45.248l-308.352-308.352a32 32 0 0 0-45.28 0l-316.768 316.768a31.968 31.968 0 0 0 22.656 54.624z" p-id="3045" fill="#ffffff"></path><path d="M538.784 457.376a32 32 0 0 0-45.28 0l-316.768 316.768a31.968 31.968 0 1 0 45.248 45.248l294.144-294.144 285.728 285.728a31.968 31.968 0 1 0 45.248-45.248l-308.32-308.352z" p-id="3046" fill="#ffffff"></path></svg>
                      </span>

                      <span class="t-btn bottom" title="返回底部" style="opacity: 0;">
                         <svg t="1681901383895" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4902" id="mx_n_1681901383896" width="22" height="22"><path d="M493.504 558.144a31.904 31.904 0 0 0 45.28 0l308.352-308.352a31.968 31.968 0 1 0-45.248-45.248l-285.728 285.728-294.176-294.144a31.968 31.968 0 1 0-45.248 45.248l316.768 316.768z" p-id="4903" fill="#ffffff"></path><path d="M801.888 460.576l-285.728 285.728-294.144-294.144a31.968 31.968 0 1 0-45.248 45.248l316.768 316.768a31.904 31.904 0 0 0 45.28 0l308.352-308.352a32 32 0 1 0-45.28-45.248z" p-id="4904" fill="#ffffff"></path></svg>
                      </span>

                </div>
`
			$('html body').append(html)
		}
		var CreateStyle = function () {
			var style =
				'#goTopBottom {position: fixed;bottom: 75px;right: 15px;z-index: 999999;display: flex;flex-direction: column;row-gap: 5px; }#goTopBottom .top {opacity: 0;}#goTopBottom .t-btn {display: flex;justify-content: center;align-items: center;width: 40px;height: 40px;cursor: pointer;color: #fff;border-radius: 4px;background-image: linear-gradient(to top right,#6966ff,#37e2d3);background-size: 100% 100%;background-color: transparent;}#goTopBottom .bottom {opacity: 0;}'
			// GM_addStyle(iconFont)
      GM_addStyle(style)
		}
		var GoTB = function () {
			var upperLimit = 100
			var scrollSpeed = 500
			var fadeSpeed = 300
			var $top = $('#goTopBottom .gotop')
			var $bottom = $('#goTopBottom .bottom')
			if (getScrollTop() > upperLimit) {
				$top.stop().fadeTo(0, 1, function () {
					$top.show()
				})
			}
			if (getScrollTop() + $(window).height() < $doc.height() - upperLimit) {
				$bottom.stop().fadeTo(0, 1, function () {
					$bottom.show()
				})
			}
			$doc.scroll(function () {
				if (getScrollTop() > upperLimit) {
					$top.stop().fadeTo(fadeSpeed, 1, function () {
						$top.css('visibility', 'visible')
					})
				} else {
					$top.stop().fadeTo(fadeSpeed, 0, function () {
						$top.css('visibility', 'hidden')
					})
				}
				if (getScrollTop() + $(window).height() < $doc.height() - upperLimit) {
					$bottom.stop().fadeTo(fadeSpeed, 1, function () {
						$bottom.css('visibility', 'visible')
					})
				} else {
					$bottom.stop().fadeTo(fadeSpeed, 0, function () {
						$bottom.css('visibility', 'hidden')
					})
				}
			})
			$('#goTopBottom span').click(function () {
				var $this = $(this)
				var clsName = $this.attr('class')
        const scrollHeight = clsName.includes('gotop') ? 0 : $doc.height()
        $('html, body').animate({
            scrollTop: scrollHeight
        },scrollSpeed)

				return false
			})
		}
		var getScrollTop = function () {
			var scrollTop = $doc.scrollTop() || $('html,body').scrollTop()
			return scrollTop
		}
		/**
		 * 拖拽
		 */
		function dragging() {
			var position = GM_getValue('gtb_pos') || {}
			$('#goTopBottom span')
				.off('.gtb')
				.on({
					'mouseover.gtb': function () {
						//$(this).css("cursor","move");
					},
					'mousedown.gtb': function (el) {
						var move = true
						var $gtbBox = $('#goTopBottom')
						var x = el.pageX - $gtbBox.offset().left
						var y = el.pageY - $gtbBox.offset().top
						$doc.on({
							'mousemove.gtb': function (docEl) {
								if (move) {
									var x1 = docEl.pageX - x
									var y1 = docEl.pageY - y
									$gtbBox.offset({
										left: x1,
										top: y1
									})
								}
							},
							'mouseup.gtb': function () {
								move = false
								$doc.off('.gtb')
							}
						})
					}
				})
		}
		this.init = function () {
			CreateStyle()
			CreateHtml()
			dragging()
			GoTB()
		}
	}
	var tbl = new TBLink()
	tbl.init()
})()
